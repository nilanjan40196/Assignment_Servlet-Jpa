package com.capg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capg.models.Book;
import com.capg.models.Library;

public class DaoImpl implements IDao{
	
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Jpa-servlet");
	private static EntityManager em = emf.createEntityManager();
	
	public void addBook(Book b) {
		em.getTransaction().begin();
		
		em.persist(b);
		
		em.getTransaction().commit();
	}
	
	public Library getLibrary(String libName) {
		EntityManager em1 = emf.createEntityManager();
		
		TypedQuery<Library> query = em1.createQuery("SELECT l FROM Library l", Library.class);
		List<Library> libs = query.getResultList();
		
		for(Library l : libs ) {
			if(l.getLibraryName().equals(libName)) {
				return l;
			}
		}
		return null;
	}
	
	public Book findBook(int bookId) {
		return em.find(Book.class,bookId);
	}

	public Book deleteBook(int bookId) {
		em.getTransaction().begin();
		Book b = findBook(bookId);
		em.remove(b);
		
		em.getTransaction().commit();
		return b;
	}
	
	public List<Book> getAllBooks(){
		EntityManager em1 = emf.createEntityManager();
		TypedQuery<Book> que = em.createQuery("SELECT b FROM Book b", Book.class);
		List<Book> books = que.getResultList();
		em1.close();
		return books;
	}
	
	public Book updateBookDetails(int id,String bname,String auth,String pub) {
		Book b = findBook(id);
		
		em.getTransaction().begin();
		
		if(bname.length()!=0) {
			b.setBookName(bname);
		}
		if(auth.length()!=0) {
			b.setAuthor(auth);
		}
		if(pub.length()!=0) {
			b.setPublisher(pub);
		}
		
		em.getTransaction().commit();
		return b;
	}

	public List<Library> getAllLibrary() {
		
		TypedQuery<Library> query = em.createQuery("SELECT l FROM Library l", Library.class);
		return query.getResultList();
	}

	public void addLibrary(Library lib) {
		if(lib!=null) {
			em.getTransaction().begin();
			em.persist(lib);
			em.getTransaction().commit();
	    }
	}
	
	public Library deleteLib(int libId) {
		
		TypedQuery<Book> q = em.createQuery("SELECT b FROM Book b, Library l WHERE b.library = l.libraryId AND l.libraryId = ?1", Book.class);
		List<Book> books = q.setParameter(1, libId).getResultList();
		
		em.getTransaction().begin();
		for(Book b : books) {
			//System.out.println(b.getBookId());
			em.remove(b);	
		}
		Library library = em.find(Library.class, libId);
		em.remove(library);
		em.getTransaction().commit();
		return library;
	}
}
