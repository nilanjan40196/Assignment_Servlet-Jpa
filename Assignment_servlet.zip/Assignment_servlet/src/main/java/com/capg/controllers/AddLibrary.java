package com.capg.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capg.dao.DaoImpl;
import com.capg.dao.IDao;
import com.capg.models.Library;

@WebServlet("/addlib")
public class AddLibrary extends HttpServlet {
	private static final long serialVersionUID = 1L;
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		IDao dao = new DaoImpl();
   		PrintWriter out = response.getWriter();
   		response.setContentType("text/html");
   		
   		Library lib = new Library();
   		lib.setLibraryId(Integer.parseInt(request.getParameter("lib_Id")));
   		lib.setLibraryName(request.getParameter("lib_name"));
   		dao.addLibrary(lib);
   		out.println("<meta http-equiv='refresh' content='4;URL=index.jsp'>");	
   		out.println("Library Added...");
   		
   	}

}
